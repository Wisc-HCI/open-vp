module.exports = {
  extends: ["custom/storybook"],
};
