@people_and_robots/open-core / [Exports](modules.md)

<h1 align="center">
  <a href="https://wisc-hci.github.io/open-vp/"><img src="https://github.com/Wisc-HCI/open-vp/assets/5341396/0c5cdbb7-e7a8-41ea-926f-2f948d7fcf5e" alt="OpenVP"></a>
</h1>

# OpenVP
A Customizable Visual Programming Environment for Robotics Applications
