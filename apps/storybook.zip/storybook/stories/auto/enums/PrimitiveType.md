[@people_and_robots/open-core](../README.md) / [Exports](../modules.md) / PrimitiveType

# Enumeration: PrimitiveType

## Table of contents

### Enumeration Members

- [Function](PrimitiveType.md#function)
- [Object](PrimitiveType.md#object)

## Enumeration Members

### Function

• **Function** = ``"FUNCTION"``

#### Defined in

[constants.ts:7](https://github.com/Wisc-HCI/open-vp/blob/7dd5e238/packages/open-core/src/constants.ts#L7)

___

### Object

• **Object** = ``"OBJECT"``

#### Defined in

[constants.ts:6](https://github.com/Wisc-HCI/open-vp/blob/7dd5e238/packages/open-core/src/constants.ts#L6)
