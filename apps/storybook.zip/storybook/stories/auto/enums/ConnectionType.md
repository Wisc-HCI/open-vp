[@people_and_robots/open-core](../README.md) / [Exports](../modules.md) / ConnectionType

# Enumeration: ConnectionType

## Table of contents

### Enumeration Members

- [Number](ConnectionType.md#number)
- [String](ConnectionType.md#string)

## Enumeration Members

### Number

• **Number** = ``"NUMBER"``

#### Defined in

[constants.ts:33](https://github.com/Wisc-HCI/open-vp/blob/7dd5e238/packages/open-core/src/constants.ts#L33)

___

### String

• **String** = ``"STRING"``

#### Defined in

[constants.ts:34](https://github.com/Wisc-HCI/open-vp/blob/7dd5e238/packages/open-core/src/constants.ts#L34)
